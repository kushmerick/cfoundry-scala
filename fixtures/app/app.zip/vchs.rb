require "sinatra"
require "cfoundry"
require "uaa"

helpers do

  def cf_endpoint
    # properties.cc.srv_api_uri
    # "http://api.dev5.sin2.beefstall.info"
    "http://api.cf-nicholask.10.111.104.81.xip.io"
  end

  def token_secret
    # properties.uaa.cc.token_secret
    "AURUBDNOURNGXRJJWMOQ"
  end

  # see commnent in "before" hook below
  def user_id
    "joe1234"
  end
  def tenant_id
    "coke"
  end
  def vdc_ids
    ["coke-fin", "coke-hr"]
  end
  def vchs_roles
    ["role1", "role2"]
  end
  def current_vdc_id
    "coke-fin"
  end

  def client
    CFoundry::V2::Client.new(cf_endpoint).tap { |client|
      client.token = create_token(session)
    }
  end

  def token_encoder
    @token_encoder ||= CF::UAA::TokenCoder.new(skey: token_secret)
  end

  def create_token(session)
    token = {
      aud: [
        "cloud_controller"
      ],
      exp: Time.now.to_i + 60*60*24*14, # 2 weeks
      scope: [
        "cloud_controller.read",
        "cloud_controller.write",
      ],
      user_id: session[:user_id],
      az_attr: {
        vchs: {
          tenant_id: session[:tenant_id],
          vdc_ids: session[:vdc_ids],
          roles: session[:vchs_roles]
        }
      }
    }
    token = token_encoder.encode(token) # https://github.com/cloudfoundry/cf-uaa-lib/blob/master/lib/uaa/token_coder.rb#L64
    "bearer #{token}"
  end

end

# sinatra configuration

set :bind, "0.0.0.0"
enable :sessions

before do
  # TODO: vCHS somehow knows the current user, tenant, etc.  In this
  # PoC, we just hardwire some particular values.  This might seem
  # like cheating, but it isn't.  Really.
  session[:user_id] ||= user_id
  session[:tenant_id] ||= tenant_id
  session[:vdc_ids] ||= vdc_ids
  session[:vchs_roles] ||= vchs_roles
  session[:current_vdc_id] ||= current_vdc_id
  session[:client] ||= client
end

# user-facing routes

get "/" do
  erb :index
end

get "/services" do
  erb :services
end

get "/service_instances" do
  erb :service_instances
end

__END__

# templates

@@ layout
<html>
  <head><title>vCHS (trusted to generate CF tokens)</title></head>
  <body>
    <%= yield %>
  </body>
</html>

@@ index
<h1>vCHS</h1>
<p><img src="http://banterlcrowe.blogs.brynmawr.edu/files/2012/11/Edam_Cheese.jpg" height="90" width="170"></p>
<hr>
<ul>
  <li><a href="/services">Services</A></li>
  <li><a href="/service_instances">Service instances</a></li>
</ul>

@@ services
<h1>vCHS: Services</h1>
<p><img src="http://banterlcrowe.blogs.brynmawr.edu/files/2012/11/Edam_Cheese.jpg" height="90" width="170"></p>
<hr>
<p><a href="/">home</a></p>
<hr>
<table border="1">
  <tr><th>label</th><th>provider</th><th>version</th><th>plans</th></tr>
  <% session[:client].services.each do |service| %>
  <tr><td><%= service.label %></td>
      <td><%= service.provider %></td>
      <td><%= service.version %></td>
      <td><%= service.service_plans.map{|p|p.name}.join(", ") %></td></tr>
  <% end %>
</table>

@@ service_instances
<h1>vCHS: Services instances</h1>
<p><img src="http://banterlcrowe.blogs.brynmawr.edu/files/2012/11/Edam_Cheese.jpg" height="90" width="170"></p>
<hr>
<p><a href="/">home</a></p>
<hr>
<table border="1">
  <tr><th>name</th><th>service</th><th>plan</th></tr>
  <% session[:client].service_instances.each do |instance| %>
  <tr><td><%= instance.name %></td>
      <td><%= instance.service_plan.service.label %></td>
      <td><%= instance.service_plan.name%></td></tr>
  <% end %>
</table>
